from langchain_community.document_loaders.recursive_url_loader import (
    RecursiveUrlLoader,
)

__all__ = ["RecursiveUrlLoader"]
