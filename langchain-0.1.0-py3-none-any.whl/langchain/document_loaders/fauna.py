from langchain_community.document_loaders.fauna import FaunaLoader

__all__ = ["FaunaLoader"]
