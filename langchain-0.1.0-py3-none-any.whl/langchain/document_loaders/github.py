from langchain_community.document_loaders.github import (
    BaseGitHubLoader,
    GitHubIssuesLoader,
)

__all__ = ["BaseGitHubLoader", "GitHubIssuesLoader"]
