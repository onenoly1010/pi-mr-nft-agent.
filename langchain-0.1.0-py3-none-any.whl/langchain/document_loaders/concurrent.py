from langchain_community.document_loaders.concurrent import (
    ConcurrentLoader,
)

__all__ = ["ConcurrentLoader"]
