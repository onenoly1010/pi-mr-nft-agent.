from langchain_community.document_loaders.generic import (
    GenericLoader,
)

__all__ = ["GenericLoader"]
