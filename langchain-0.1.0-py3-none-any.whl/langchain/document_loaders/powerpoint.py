from langchain_community.document_loaders.powerpoint import UnstructuredPowerPointLoader

__all__ = ["UnstructuredPowerPointLoader"]
