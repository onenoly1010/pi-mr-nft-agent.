from langchain_community.document_loaders.google_speech_to_text import (
    GoogleSpeechToTextLoader,
)

__all__ = ["GoogleSpeechToTextLoader"]
