from langchain_community.docstore.arbitrary_fn import DocstoreFn

__all__ = ["DocstoreFn"]
