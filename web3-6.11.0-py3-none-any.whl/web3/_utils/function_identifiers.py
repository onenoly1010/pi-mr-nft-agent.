class FallbackFn:
    pass


class ReceiveFn:
    pass
